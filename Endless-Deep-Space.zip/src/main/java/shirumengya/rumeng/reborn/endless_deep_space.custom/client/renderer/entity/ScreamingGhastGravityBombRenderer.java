package shirumengya.rumeng.reborn.endless_deep_space.custom.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Matrix3f;
import com.mojang.math.Matrix4f;
import com.mojang.math.Vector3f;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import shirumengya.rumeng.reborn.endless_deep_space.custom.entity.projectile.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.util.RandomSource;

@OnlyIn(Dist.CLIENT)
public class ScreamingGhastGravityBombRenderer extends EntityRenderer<ScreamingGhastGravityBomb> {
   private static final ResourceLocation TEXTURE_LOCATION = new ResourceLocation("textures/entity/enderdragon/dragon_fireball.png");
   private static final RenderType RENDER_TYPE = RenderType.entityCutoutNoCull(TEXTURE_LOCATION);
   private static final float HALF_SQRT_3 = (float)(Math.sqrt(3.0D) / 2.0D);

   public ScreamingGhastGravityBombRenderer(EntityRendererProvider.Context p_173962_) {
      super(p_173962_);
   }

   protected int getBlockLightLevel(ScreamingGhastGravityBomb p_114087_, BlockPos p_114088_) {
      return 15;
   }

   public void render(ScreamingGhastGravityBomb p_114080_, float p_114081_, float p_114082_, PoseStack p_114083_, MultiBufferSource p_114084_, int p_114085_) {
      p_114083_.pushPose();
      if (p_114080_.getHalfHealthPower()) {
      	p_114083_.scale(4.0F, 4.0F, 4.0F);
      } else {
      	p_114083_.scale(1.0F, 1.0F, 1.0F);
      }
      p_114083_.mulPose(this.entityRenderDispatcher.cameraOrientation());
      p_114083_.mulPose(Vector3f.YP.rotationDegrees(180.0F));
      PoseStack.Pose posestack$pose = p_114083_.last();
      Matrix4f matrix4f = posestack$pose.pose();
      Matrix3f matrix3f = posestack$pose.normal();
      VertexConsumer vertexconsumer = p_114084_.getBuffer(RENDER_TYPE);
      vertex(vertexconsumer, matrix4f, matrix3f, p_114085_, 0.0F, 0, 0, 1);
      vertex(vertexconsumer, matrix4f, matrix3f, p_114085_, 1.0F, 0, 1, 1);
      vertex(vertexconsumer, matrix4f, matrix3f, p_114085_, 1.0F, 1, 1, 0);
      vertex(vertexconsumer, matrix4f, matrix3f, p_114085_, 0.0F, 1, 0, 0);
      p_114083_.popPose();
      if (p_114080_.getTimer() > 0) {
      	this.renderLikeEnderDragonDeathAnimation(p_114080_, p_114081_, p_114082_, p_114083_, p_114084_, p_114085_);
      }
      super.render(p_114080_, p_114081_, p_114082_, p_114083_, p_114084_, p_114085_);
   }

   private void renderLikeEnderDragonDeathAnimation(ScreamingGhastGravityBomb p_114208_, float p_114209_, float p_114210_, PoseStack p_114211_, MultiBufferSource p_114212_, int p_114213_) {
   		float f5 = ((float)p_114208_.getTimer() + p_114210_) / 240.0F;
       	float f7 = Math.min(f5 > 0.8F ? (f5 - 0.8F) / 0.2F : 0.0F, 1.0F);
       	RandomSource randomsource = RandomSource.create(432L);
       	VertexConsumer vertexconsumer2 = p_114212_.getBuffer(RenderType.lightning());
       	p_114211_.pushPose();
       	p_114211_.translate(0.0D, 0.25D, 0.0D);
       	if (p_114208_.getHalfHealthPower()) {
       		p_114211_.scale(2.0F, 2.0F, 2.0F);
       	}
       	for(int i = 0; (float)i < (f5 + f5 * f5) / 2.0F * 60.0F; ++i) {
          	p_114211_.mulPose(Vector3f.XP.rotationDegrees(randomsource.nextFloat() * 360.0F));
       		p_114211_.mulPose(Vector3f.YP.rotationDegrees(randomsource.nextFloat() * 360.0F));
          	p_114211_.mulPose(Vector3f.ZP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.XP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.YP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.ZP.rotationDegrees(randomsource.nextFloat() * 360.0F + f5 * 90.0F));
           	float f3 = randomsource.nextFloat() * 20.0F + 5.0F + f7 * 10.0F;
           	float f4 = randomsource.nextFloat() * 2.0F + 1.0F + f7 * 2.0F;
           	Matrix4f matrix4f = p_114211_.last().pose();
           	int j = (int)(255.0F * (1.0F - f7));
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex2(vertexconsumer2, matrix4f, f3, f4, p_114208_);
           	vertex3(vertexconsumer2, matrix4f, f3, f4, p_114208_);
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex3(vertexconsumer2, matrix4f, f3, f4, p_114208_);
           	vertex4(vertexconsumer2, matrix4f, f3, f4, p_114208_);
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex4(vertexconsumer2, matrix4f, f3, f4, p_114208_);
           	vertex2(vertexconsumer2, matrix4f, f3, f4, p_114208_);
       	}
      	p_114211_.popPose();
   	}

   	private static void vertex01(VertexConsumer p_114220_, Matrix4f p_114221_, int p_114222_) {
      	p_114220_.vertex(p_114221_, 0.0F, 0.0F, 0.0F).color(255, 255, 255, p_114222_).endVertex();
   	}

   	private static void vertex2(VertexConsumer p_114215_, Matrix4f p_114216_, float p_114217_, float p_114218_, ScreamingGhastGravityBomb p_114208_) {
      	p_114215_.vertex(p_114216_, -HALF_SQRT_3 * p_114218_, p_114217_, -0.5F * p_114218_).color(255, 0, p_114208_.getHalfHealthPower() ? 0 : 255, 0).endVertex();
   	}

   	private static void vertex3(VertexConsumer p_114224_, Matrix4f p_114225_, float p_114226_, float p_114227_, ScreamingGhastGravityBomb p_114208_) {
      	p_114224_.vertex(p_114225_, HALF_SQRT_3 * p_114227_, p_114226_, -0.5F * p_114227_).color(255, 0, p_114208_.getHalfHealthPower() ? 0 : 255, 0).endVertex();
   	}

   	private static void vertex4(VertexConsumer p_114229_, Matrix4f p_114230_, float p_114231_, float p_114232_, ScreamingGhastGravityBomb p_114208_) {
      	p_114229_.vertex(p_114230_, 0.0F, p_114231_, 1.0F * p_114232_).color(255, 0, p_114208_.getHalfHealthPower() ? 0 : 255, 0).endVertex();
   	}

   private static void vertex(VertexConsumer p_114090_, Matrix4f p_114091_, Matrix3f p_114092_, int p_114093_, float p_114094_, int p_114095_, int p_114096_, int p_114097_) {
      p_114090_.vertex(p_114091_, p_114094_ - 0.5F, (float)p_114095_ - 0.25F, 0.0F).color(255, 255, 255, 255).uv((float)p_114096_, (float)p_114097_).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(p_114093_).normal(p_114092_, 0.0F, 1.0F, 0.0F).endVertex();
   }

   public ResourceLocation getTextureLocation(ScreamingGhastGravityBomb p_114078_) {
      return TEXTURE_LOCATION;
   }
}