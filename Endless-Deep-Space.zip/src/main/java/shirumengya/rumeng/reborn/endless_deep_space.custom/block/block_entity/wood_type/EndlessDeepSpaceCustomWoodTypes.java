package shirumengya.rumeng.reborn.endless_deep_space.custom.block.block_entity.wood_type;

import net.minecraft.world.level.block.state.properties.WoodType;

public class EndlessDeepSpaceCustomWoodTypes {
    public static WoodType PETRIFIED_OAK = WoodType.create("petrified_oak");
    public static WoodType TRANSPARENT = WoodType.create("transparent");
}
