package shirumengya.rumeng.reborn.endless_deep_space.custom.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.HoverEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import java.math.BigInteger;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

@Mod.EventBusSubscriber
public class CreateUUIDCommand {

   @SubscribeEvent
   public static void register(RegisterCommandsEvent event) {
      event.getDispatcher().register(Commands.literal("create_UUID")
	  .executes((p_138593_) -> {
	  	 String i = Mth.createInsecureUUID(RandomSource.create()).toString();
         Component component = ComponentUtils.wrapInSquareBrackets(Component.literal(String.valueOf(i)).withStyle((p_180514_) -> {
            return p_180514_.withColor(ChatFormatting.GOLD).withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, String.valueOf(i))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.translatable("chat.copy.click"))).withInsertion(String.valueOf(i));
         }));
         p_138593_.getSource().sendSuccess(Component.translatable("commands.big_integer.success", component), false);
         return 0;
      }));
   }
}