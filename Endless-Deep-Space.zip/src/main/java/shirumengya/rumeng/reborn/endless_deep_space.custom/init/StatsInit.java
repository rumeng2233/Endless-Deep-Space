package shirumengya.rumeng.reborn.endless_deep_space.custom.init;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.stats.StatFormatter;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.stats.StatType;
import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.ForgeRegistry;
import shirumengya.rumeng.reborn.endless_deep_space.*;
import net.minecraft.client.renderer.GameRenderer;

public class StatsInit {
	
	public static final DeferredRegister<ResourceLocation> STATS = DeferredRegister.create(Registry.CUSTOM_STAT_REGISTRY, EndlessDeepSpaceMod.MODID);
	private static final List<Runnable> STAT_SETUP = new ArrayList<>();

	public static final RegistryObject<ResourceLocation> BOSS_DEFEAT_TIMES = makeStat("boss_defeat_times", StatFormatter.DEFAULT);

	public static void init() {
		STAT_SETUP.forEach(Runnable::run);
	}

	private static RegistryObject<ResourceLocation> makeStat(String key, StatFormatter type) {
		ResourceLocation resourcelocation = EndlessDeepSpaceMod.prefix(key);
		STAT_SETUP.add(() -> Stats.CUSTOM.get(resourcelocation, type));
		return STATS.register(key, () -> resourcelocation);
	}
}
