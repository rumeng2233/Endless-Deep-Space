package shirumengya.rumeng.reborn.endless_deep_space.custom.sounds;

import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.Music;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.sounds.*;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class EndlessDeepSpaceMusicManager {
   private static final int STARTING_DELAY = 100;
   private static final RandomSource random = RandomSource.create();
   @Nullable
   private static SoundInstance currentMusic;
   private static int nextSongDelay = 100;
   private static final Logger LOGGER = LogUtils.getLogger();

   public EndlessDeepSpaceMusicManager() {
   }

   public static void tick() {
      Music music = Minecraft.getInstance().getSituationalMusic();
      if (currentMusic != null) {
         if (!music.getEvent().getLocation().equals(currentMusic.getLocation()) && music.replaceCurrentMusic()) {
            Minecraft.getInstance().getSoundManager().stop(currentMusic);
            nextSongDelay = Mth.nextInt(random, 0, music.getMinDelay() / 2);
         }

         if (!Minecraft.getInstance().getSoundManager().isActive(currentMusic)) {
            currentMusic = null;
            nextSongDelay = Math.min(nextSongDelay, Mth.nextInt(random, music.getMinDelay(), music.getMaxDelay()));
         }
      }

      nextSongDelay = Math.min(nextSongDelay, music.getMaxDelay());
      if (currentMusic == null && nextSongDelay-- <= 0) {
         startPlaying(music);
      }

   }

   public static void startPlaying(Music p_120185_) {
      currentMusic = SimpleSoundInstance.forMusic(p_120185_.getEvent());
      if (currentMusic.getSound() != SoundManager.EMPTY_SOUND) {
         Minecraft.getInstance().getSoundManager().play(currentMusic);
         LOGGER.info("Start playing music:[" + currentMusic.getLocation() + "]");
      }

      nextSongDelay = Integer.MAX_VALUE;
   }

   public static void stopPlaying() {
      if (currentMusic != null) {
         Minecraft.getInstance().getSoundManager().stop(currentMusic);
         LOGGER.info("Stop playing music:[" + currentMusic.getLocation() + "]");
         currentMusic = null;
      }

      nextSongDelay += 100;
   }

   public static boolean isPlayingMusic(Music p_120188_) {
      return currentMusic == null ? false : p_120188_.getEvent().getLocation().equals(currentMusic.getLocation());
   }
}