package shirumengya.rumeng.reborn.endless_deep_space.custom.client.renderer.blockentity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Vector3f;
import net.minecraft.client.model.BookModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.Material;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import shirumengya.rumeng.reborn.endless_deep_space.custom.block.block_entity.*;
import net.minecraft.client.renderer.blockentity.*;
import net.minecraft.world.phys.*;
import shirumengya.rumeng.reborn.endless_deep_space.custom.client.renderer.EndlessDeepSpaceRenderTypes;
import com.mojang.math.Matrix4f;
import net.minecraft.core.Direction;

@OnlyIn(Dist.CLIENT)
public class BrokenBookRenderer implements BlockEntityRenderer<BrokenBookBlockEntity> {
   public static final Material BOOK_LOCATION = new Material(TextureAtlas.LOCATION_BLOCKS, new ResourceLocation("entity/broken_book_book"));
   private final BookModel bookModel;

   public BrokenBookRenderer(BlockEntityRendererProvider.Context p_173619_) {
      this.bookModel = new BookModel(p_173619_.bakeLayer(ModelLayers.BOOK));
   }

   public void render(BrokenBookBlockEntity p_112418_, float p_112419_, PoseStack p_112420_, MultiBufferSource p_112421_, int p_112422_, int p_112423_) {
      p_112420_.pushPose();
      p_112420_.translate(0.5D, 0.4D, 0.5D);
      float f = (float)p_112418_.time + p_112419_;
      p_112420_.translate(0.0D, (double)(0.1F + Mth.sin(f * 0.1F) * 0.01F), 0.0D);

      float f1;
      for(f1 = p_112418_.rot - p_112418_.oRot; f1 >= (float)Math.PI; f1 -= ((float)Math.PI * 2F)) {
      }

      while(f1 < -(float)Math.PI) {
         f1 += ((float)Math.PI * 2F);
      }

      float f2 = p_112418_.oRot + f1 * p_112419_;
      p_112420_.mulPose(Vector3f.YP.rotation(-f2));
      p_112420_.mulPose(Vector3f.ZP.rotationDegrees(80.0F));
      float f3 = Mth.lerp(p_112419_, p_112418_.oFlip, p_112418_.flip);
      float f4 = Mth.frac(f3 + 0.25F) * 1.6F - 0.3F;
      float f5 = Mth.frac(f3 + 0.75F) * 1.6F - 0.3F;
      float f6 = Mth.lerp(p_112419_, p_112418_.oOpen, p_112418_.open);
      this.bookModel.setupAnim(f, Mth.clamp(f4, 0.0F, 1.0F), Mth.clamp(f5, 0.0F, 1.0F), f6);
      VertexConsumer vertexconsumer = BOOK_LOCATION.buffer(p_112421_, RenderType::entitySolid);
      this.bookModel.render(p_112420_, vertexconsumer, p_112422_, p_112423_, 1.0F, 1.0F, 1.0F, 1.0F);
      p_112420_.popPose();
      Matrix4f matrix4f = p_112420_.last().pose();
      this.renderCube(p_112418_, matrix4f, p_112421_.getBuffer(EndlessDeepSpaceRenderTypes.LikeEndGatewayRender(new ResourceLocation("entity/broken_book_book"), new ResourceLocation("entity/broken_book_book"))));
   }

    public boolean shouldRenderOffScreen(BrokenBookBlockEntity p_112138_) {
      return true;
   }

   	public int getViewDistance() {
      return Integer.MAX_VALUE;
   }

   	public boolean shouldRender(BrokenBookBlockEntity p_173531_, Vec3 p_173532_) {
      return true;
   }

   private void renderCube(BrokenBookBlockEntity p_173691_, Matrix4f p_173692_, VertexConsumer p_173693_) {
      float f = this.getOffsetDown();
      float f1 = this.getOffsetUp();
      this.renderFace(p_173691_, p_173692_, p_173693_, 0.0F, 1.0F, f, f1, 1.0F, 1.0F, 1.0F, 1.0F, Direction.SOUTH);
      this.renderFace(p_173691_, p_173692_, p_173693_, 0.0F, 1.0F, f1, f, 0.0F, 0.0F, 0.0F, 0.0F, Direction.NORTH);
      this.renderFace(p_173691_, p_173692_, p_173693_, 1.0F, 1.0F, f1, f, 0.0F, 1.0F, 1.0F, 0.0F, Direction.EAST);
      this.renderFace(p_173691_, p_173692_, p_173693_, 0.0F, 0.0F, f, f1, 0.0F, 1.0F, 1.0F, 0.0F, Direction.WEST);
      this.renderFace(p_173691_, p_173692_, p_173693_, 0.0F, 1.0F, f, f, 0.0F, 0.0F, 1.0F, 1.0F, Direction.DOWN);
      this.renderFace(p_173691_, p_173692_, p_173693_, 0.0F, 1.0F, f1, f1, 1.0F, 1.0F, 0.0F, 0.0F, Direction.UP);
   }

   private void renderFace(BrokenBookBlockEntity p_173695_, Matrix4f p_173696_, VertexConsumer p_173697_, float p_173698_, float p_173699_, float p_173700_, float p_173701_, float p_173702_, float p_173703_, float p_173704_, float p_173705_, Direction p_173706_) {
         p_173697_.vertex(p_173696_, p_173698_, p_173700_, p_173702_).endVertex();
         p_173697_.vertex(p_173696_, p_173699_, p_173700_, p_173703_).endVertex();
         p_173697_.vertex(p_173696_, p_173699_, p_173701_, p_173704_).endVertex();
         p_173697_.vertex(p_173696_, p_173698_, p_173701_, p_173705_).endVertex();
   }

   protected float getOffsetUp() {
		return 0.4F;
   }

   protected float getOffsetDown() {
		return 0.0F;
   }
}