package shirumengya.rumeng.reborn.endless_deep_space.custom.mixin;

import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.Music;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.client.sounds.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.*;
import org.spongepowered.asm.mixin.*;
import shirumengya.rumeng.reborn.endless_deep_space.custom.sounds.*;

@Mixin(MusicManager.class)
public class MusicManagerMixin {

	@Inject(method = {"tick"}, at = {@At("HEAD")}, cancellable = true)
	public void tick(CallbackInfo info) {
		EndlessDeepSpaceMusicManager.tick();
		info.cancel();
   	}
}
