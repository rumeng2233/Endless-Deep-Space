package shirumengya.rumeng.reborn.endless_deep_space.custom.util.item;

import shirumengya.rumeng.reborn.endless_deep_space.custom.init.ItemInit;
import shirumengya.rumeng.reborn.endless_deep_space.init.EndlessDeepSpaceModItems;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.core.Registry;

public class SpecialItemProperties {
    public static void addCustomSpecialItemProperties() {
    }
}
