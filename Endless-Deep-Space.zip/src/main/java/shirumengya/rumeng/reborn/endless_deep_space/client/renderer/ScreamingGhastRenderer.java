
package shirumengya.rumeng.reborn.endless_deep_space.client.renderer;

import shirumengya.rumeng.reborn.endless_deep_space.entity.ScreamingGhastEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.GhastModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Vector3f;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.RandomSource;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Matrix4f;
import net.minecraft.client.renderer.MultiBufferSource;

public class ScreamingGhastRenderer extends MobRenderer<ScreamingGhastEntity, GhastModel<ScreamingGhastEntity>> {

private static final ResourceLocation GHAST_LOCATION = new ResourceLocation("textures/entity/ghast/ghast.png");
private static final ResourceLocation GHAST_SHOOTING_LOCATION = new ResourceLocation("textures/entity/ghast/ghast_shooting.png");
private static final float HALF_SQRT_3 = (float)(Math.sqrt(3.0D) / 2.0D);

	public ScreamingGhastRenderer(EntityRendererProvider.Context context) {
		super(context, new GhastModel(context.bakeLayer(ModelLayers.GHAST)), 1.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ScreamingGhastEntity entity) {
		return entity.isCharging() ? GHAST_SHOOTING_LOCATION : GHAST_LOCATION;
	}

	public void render(ScreamingGhastEntity p_115455_, float p_115456_, float p_115457_, PoseStack p_115458_, MultiBufferSource p_115459_, int p_115460_) {
		if (p_115455_.ScreamingGhastDeathTime > 0) {
			this.renderLikeEnderDragonDeathAnimation(p_115455_, p_115456_, p_115457_, p_115458_, p_115459_, p_115460_);
		}
		super.render(p_115455_, p_115456_, p_115457_, p_115458_, p_115459_, p_115460_);
	}

	private void renderLikeEnderDragonDeathAnimation(ScreamingGhastEntity p_114208_, float p_114209_, float p_114210_, PoseStack p_114211_, MultiBufferSource p_114212_, int p_114213_) {
   		float f5 = ((float)p_114208_.ScreamingGhastDeathTime + p_114210_) / 100.0F;
       	float f7 = Math.min(f5 > 0.8F ? (f5 - 0.8F) / 0.2F : 0.0F, 1.0F);
       	RandomSource randomsource = RandomSource.create(432L);
       	VertexConsumer vertexconsumer2 = p_114212_.getBuffer(RenderType.lightning());
       	p_114211_.pushPose();
       	p_114211_.translate(0.0D, 2.5D, 0.0D);
       	p_114211_.scale(4.0F, 4.0F, 4.0F);
       	for(int i = 0; (float)i < (f5 + f5 * f5) / 2.0F * 60.0F; ++i) {
          	p_114211_.mulPose(Vector3f.XP.rotationDegrees(randomsource.nextFloat() * 360.0F));
       		p_114211_.mulPose(Vector3f.YP.rotationDegrees(randomsource.nextFloat() * 360.0F));
          	p_114211_.mulPose(Vector3f.ZP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.XP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.YP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.ZP.rotationDegrees(randomsource.nextFloat() * 360.0F + f5 * 90.0F));
           	float f3 = randomsource.nextFloat() * 20.0F + 5.0F + f7 * 10.0F;
           	float f4 = randomsource.nextFloat() * 2.0F + 1.0F + f7 * 2.0F;
           	Matrix4f matrix4f = p_114211_.last().pose();
           	int j = (int)(255.0F * (1.0F - f7));
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex2(vertexconsumer2, matrix4f, f3, f4);
           	vertex3(vertexconsumer2, matrix4f, f3, f4);
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex3(vertexconsumer2, matrix4f, f3, f4);
           	vertex4(vertexconsumer2, matrix4f, f3, f4);
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex4(vertexconsumer2, matrix4f, f3, f4);
           	vertex2(vertexconsumer2, matrix4f, f3, f4);
       	}
      	p_114211_.popPose();
   	}

   	private static void vertex01(VertexConsumer p_114220_, Matrix4f p_114221_, int p_114222_) {
      	p_114220_.vertex(p_114221_, 0.0F, 0.0F, 0.0F).color(255, 65, 5, p_114222_).endVertex();
   	}

   	private static void vertex2(VertexConsumer p_114215_, Matrix4f p_114216_, float p_114217_, float p_114218_) {
      	p_114215_.vertex(p_114216_, -HALF_SQRT_3 * p_114218_, p_114217_, -0.5F * p_114218_).color(255, 65, 5, 0).endVertex();
   	}

   	private static void vertex3(VertexConsumer p_114224_, Matrix4f p_114225_, float p_114226_, float p_114227_) {
      	p_114224_.vertex(p_114225_, HALF_SQRT_3 * p_114227_, p_114226_, -0.5F * p_114227_).color(255, 65, 5, 0).endVertex();
   	}

   	private static void vertex4(VertexConsumer p_114229_, Matrix4f p_114230_, float p_114231_, float p_114232_) {
      	p_114229_.vertex(p_114230_, 0.0F, p_114231_, 1.0F * p_114232_).color(255, 65, 5, 0).endVertex();
   	}

	protected void scale(ScreamingGhastEntity p_114757_, PoseStack p_114758_, float p_114759_) {
		float i = ((4.5F * p_114757_.ScreamingGhastDeathTime) / 10);
		if (i < 4.5F) {
			i = 4.5F;
		}
      	p_114758_.scale(i, i, i);
   	}
}
