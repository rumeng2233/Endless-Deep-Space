
package shirumengya.rumeng.reborn.endless_deep_space.client.renderer;

import shirumengya.rumeng.reborn.endless_deep_space.entity.ThunderDrownedEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.ChickenModel;
import net.minecraft.client.renderer.entity.DrownedRenderer;

public class ThunderDrownedRenderer extends DrownedRenderer {
	public ThunderDrownedRenderer(EntityRendererProvider.Context context) {
		super(context);
	}
}