
package shirumengya.rumeng.reborn.endless_deep_space.client.renderer;
import shirumengya.rumeng.reborn.endless_deep_space.entity.WitherestEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.WitherBossModel;
import net.minecraft.client.renderer.entity.layers.WitherArmorLayer;
import net.minecraft.core.BlockPos;
import com.mojang.blaze3d.vertex.PoseStack;
import shirumengya.rumeng.reborn.endless_deep_space.custom.client.renderer.entity.layers.WitherestArmorLayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SlimeModel;
import shirumengya.rumeng.reborn.endless_deep_space.custom.client.renderer.EndlessDeepSpaceRenderTypes;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Matrix4f;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.Direction;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.math.Matrix4f;
import net.minecraft.client.renderer.texture.TextureAtlas;
import com.mojang.math.Vector3f;
import net.minecraft.util.RandomSource;

public class WitherestRenderer extends MobRenderer<WitherestEntity, WitherBossModel<WitherestEntity>> {

   private static final ResourceLocation WITHER_INVULNERABLE_LOCATION = new ResourceLocation("textures/entity/wither/wither_invulnerable.png");
   private static final ResourceLocation WITHER_LOCATION = new ResourceLocation("textures/entity/wither/wither.png");
   private static final float HALF_SQRT_3 = (float)(Math.sqrt(3.0D) / 2.0D);

	public WitherestRenderer(EntityRendererProvider.Context context) {
		super(context, new WitherBossModel(context.bakeLayer(ModelLayers.WITHER)), 1f);
		this.addLayer(new WitherestArmorLayer(this, context.getModelSet()));
	}

	public void render(WitherestEntity p_115455_, float p_115456_, float p_115457_, PoseStack p_115458_, MultiBufferSource p_115459_, int p_115460_) {
		if (p_115455_.WitherestDeathTime > 0) {
			this.renderLikeEnderDragonDeathAnimation(p_115455_, p_115456_, p_115457_, p_115458_, p_115459_, p_115460_);
		}
		super.render(p_115455_, p_115456_, p_115457_, p_115458_, p_115459_, p_115460_);
	}

	private void renderLikeEnderDragonDeathAnimation(WitherestEntity p_114208_, float p_114209_, float p_114210_, PoseStack p_114211_, MultiBufferSource p_114212_, int p_114213_) {
   		float f5 = ((float)p_114208_.WitherestDeathTime + p_114210_) / 400.0F;
       	float f7 = Math.min(f5 > 0.8F ? (f5 - 0.8F) / 0.2F : 0.0F, 1.0F);
       	RandomSource randomsource = RandomSource.create(432L);
       	VertexConsumer vertexconsumer2 = p_114212_.getBuffer(RenderType.lightning());
       	p_114211_.pushPose();
       	p_114211_.translate(0.0D, 1.75D, 0.0D);
       	for(int i = 0; (float)i < (f5 + f5 * f5) / 2.0F * 60.0F; ++i) {
          	p_114211_.mulPose(Vector3f.XP.rotationDegrees(randomsource.nextFloat() * 360.0F));
       		p_114211_.mulPose(Vector3f.YP.rotationDegrees(randomsource.nextFloat() * 360.0F));
          	p_114211_.mulPose(Vector3f.ZP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.XP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.YP.rotationDegrees(randomsource.nextFloat() * 360.0F));
           	p_114211_.mulPose(Vector3f.ZP.rotationDegrees(randomsource.nextFloat() * 360.0F + f5 * 90.0F));
           	float f3 = randomsource.nextFloat() * 20.0F + 5.0F + f7 * 10.0F;
           	float f4 = randomsource.nextFloat() * 2.0F + 1.0F + f7 * 2.0F;
           	Matrix4f matrix4f = p_114211_.last().pose();
           	int j = (int)(255.0F * (1.0F - f7));
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex2(vertexconsumer2, matrix4f, f3, f4);
           	vertex3(vertexconsumer2, matrix4f, f3, f4);
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex3(vertexconsumer2, matrix4f, f3, f4);
           	vertex4(vertexconsumer2, matrix4f, f3, f4);
           	vertex01(vertexconsumer2, matrix4f, j);
           	vertex4(vertexconsumer2, matrix4f, f3, f4);
           	vertex2(vertexconsumer2, matrix4f, f3, f4);
       	}
      	p_114211_.popPose();
   	}

   	private static void vertex01(VertexConsumer p_114220_, Matrix4f p_114221_, int p_114222_) {
      	p_114220_.vertex(p_114221_, 0.0F, 0.0F, 0.0F).color(0, 153, 204, p_114222_).endVertex();
   	}

   	private static void vertex2(VertexConsumer p_114215_, Matrix4f p_114216_, float p_114217_, float p_114218_) {
      	p_114215_.vertex(p_114216_, -HALF_SQRT_3 * p_114218_, p_114217_, -0.5F * p_114218_).color(0, 153, 204, 0).endVertex();
   	}

   	private static void vertex3(VertexConsumer p_114224_, Matrix4f p_114225_, float p_114226_, float p_114227_) {
      	p_114224_.vertex(p_114225_, HALF_SQRT_3 * p_114227_, p_114226_, -0.5F * p_114227_).color(0, 153, 204, 0).endVertex();
   	}

   	private static void vertex4(VertexConsumer p_114229_, Matrix4f p_114230_, float p_114231_, float p_114232_) {
      	p_114229_.vertex(p_114230_, 0.0F, p_114231_, 1.0F * p_114232_).color(0, 153, 204, 0).endVertex();
   	}

	@Override
	protected int getBlockLightLevel(WitherestEntity p_116443_, BlockPos p_116444_) {
      	return 15;
   	}

	@Override
	public ResourceLocation getTextureLocation(WitherestEntity entity) {
		int i = entity.getInvulnerableTicks();
      	return i > 0 && (i > 80 || i / 5 % 2 != 1) ? WITHER_LOCATION : WITHER_INVULNERABLE_LOCATION;
	}

	@Override
   protected void scale(WitherestEntity p_116439_, PoseStack p_116440_, float p_116441_) {
      float f = 2.0F;
      int i = p_116439_.getInvulnerableTicks();
      if (i > 0) {
         f -= ((float)i - p_116441_) / 220.0F * 0.5F;
      }
      if (p_116439_.WitherestDeathTime > 0) {
      	f = 100.0F;
      }
      p_116440_.scale(f, f, f);
   }
}
